<?php
    session_start();
    include_once 'connect.php';
    
    $Email = $_SESSION["emailid"];
    $qr = mysql_query("select * from tbl_registration where email = '$Email'");
    $r = mysql_fetch_array($qr);
    $id = $r["id"];//table id of the user
    echo $post_id=$_SESSION["post_id"];
    $qr4 = mysql_query("delete from likepost where mem_id = '$id' and post_id='$post_id'");
    $qf = mysql_query("select * from likepost where post_id = '$post_id'");
    $rn= mysql_num_rows($qf);
    $q11 = mysql_query("select * from likepost where mem_id = '$id' and post_id='$post_id'");
    $rn11=  mysql_num_rows($q11);

?>