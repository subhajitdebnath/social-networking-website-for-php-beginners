<?php

include_once 'connect.php';

session_start();
$Email = $_SESSION["emailid"];
$qr = mysql_query("select * from tbl_registration where email = '$Email'");
$r = mysql_fetch_array($qr);
$id = $r["id"];//table id of the user

//insertion values
$post = $_REQUEST["post"];
//inserting into table...
$qr = mysql_query("insert into tbl7_posts values ('','$post','$id',now())");
if($qr)
    {
        echo "<script>alert('Successfully Posted')</script>";
        echo "<script>window.location.href='page12timeline.php'</script>";
    }
    else 
    {
        echo "<script>alert('Failed.Please try Again.')</script>";
        echo "<script>window.location.href='page11CreatePost.php'</script>";
    }


?>